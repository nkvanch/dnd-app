# Grimoire — QA Testing Guide

Step-by-step manual testing for every area of the app.
Each test includes: what to do, what to expect, and what a failure looks like.

Run after every EAS build before sharing with anyone.

---

## HOW TO USE THIS GUIDE

Work through the tests in order. Each section depends on the previous one.
Mark each test as PASS / FAIL / SKIP.

When something fails, note:
- Which step failed
- What you expected
- What actually happened
- Any error message shown

---

# PART 1 — CHARACTER CREATION

## Test 1.1 — Create a basic Fighter (the smoke test)

This covers the most common path. Do this first.

**Steps:**
1. Open the app. You should see the Home screen with "No characters yet."
2. Tap **Create Character** (gold button on Home, or + New on Characters tab).
3. Enter name **"Thorin"**, leave level at **1**. Tap Continue.
4. You should arrive at the **Creation Hub** showing all steps incomplete (red ✗).
5. Tap **Race**. Select **Dwarf**. On the detail screen, choose subrace **Mountain Dwarf**. Tap Select Race.
6. You should return to Hub. Race shows ✓.
7. Tap **Class**. Select **Fighter**. Review details. Tap Select Class.
8. Hub shows Class ✓.
9. Tap **Ability Scores**. Select **Standard Array**. Assign: STR 15, DEX 13, CON 14, INT 10, WIS 12, CHA 8. Tap Confirm Scores.
10. Hub shows Ability Scores ✓.
11. Tap **Background**. Select **Soldier**. Choose personality options. Tap Select Background.
12. Hub shows Background ✓.
13. Tap **Skills**. You should see Athletics and Intimidation already listed as "from background" and greyed out. Choose 2 more from the Fighter list. Tap Confirm Skills.
14. Hub shows Skills ✓.
15. Tap **Equipment**. Make selections. Tap through. Hub shows Equipment ✓.
16. Tap **Spells**. Fighter has no spells — you should see "This class doesn't use spells" or similar. Hub shows Spells ✓.
17. Hub shows **Review Character →** button (gold). Tap it.
18. Review screen shows: Name Thorin, Level 1, Race dwarf, Class fighter, Background soldier.
19. **Verify the numbers:**
    - STR 17 (15 base + 2 Mountain Dwarf bonus), DEX 13, CON 16 (14 + 2 Mountain Dwarf), INT 10, WIS 12, CHA 8
    - HP: 10 + CON modifier (+3) = **13**
    - AC: default 11 (no armor yet; DEX +1 modifier + base 10)
    - Initiative: +1 (DEX modifier)
    - Speed: 25 (Dwarf base speed)
20. Tap **Save Character**.
21. You should arrive at the Home screen. A "Thorin" card should be visible.

**What to check specifically:**
- STR and CON are both boosted by +2 from Mountain Dwarf (not from base stats)
- HP is NOT 10 (that would mean CON modifier isn't being applied)
- HP is NOT 14 (that would mean racial CON bonus is being double-counted)
- Speed is 25 (Dwarf), NOT 30 (Human default)
- Skill proficiencies include Athletics and Intimidation from background PLUS the 2 you picked

**Common failures at this step:**
- Racial bonuses not showing on review → stat_modifier effects not working
- HP shows 10 → CON modifier not applied in recalculateAllHP
- HP shows wrong value → race applied before/after scores in wrong order
- Speed shows 30 → Dwarf speed effect not being applied

---

## Test 1.2 — Create a Wizard (spellcaster path)

**Steps:**
1. Create Character → Name: **"Elara"**, Level 1.
2. Race: **High Elf** (subrace: High Elf). Tap Select Race.
3. Class: **Wizard**. Tap Select Class.
4. Ability Scores → Standard Array: STR 8, DEX 14, CON 13, INT 15, WIS 12, CHA 10. Confirm.
5. Background: **Sage**. Confirm.
6. Skills: Arcana and History from background are pre-marked. Pick 2 from the Wizard list (Insight, Investigation, Medicine, Religion — pick Insight and Medicine). Confirm.
7. Equipment: Choose quarterstaff and scholar's pack. Confirm.
8. Spells: You should see a spell list filtered to Wizard spells only.
   - Pick 3 cantrips (e.g. Fire Bolt, Mage Hand, Minor Illusion)
   - Pick 6 known spells (e.g. Magic Missile, Shield, Sleep, Burning Hands, Identify, Charm Person)
   - Confirm.
9. Review. Verify:
   - INT 16 (15 + 1 High Elf bonus)
   - DEX 16 (14 + 2 High Elf bonus) — High Elf is +2 DEX +1 INT
   - HP: 6 + CON modifier (+1) = **7**
   - AC: 12 (10 base + DEX +2) — no armor equipped
   - Speed: 30
   - Spell Save DC: 13 (8 + Prof +2 + INT +3)
   - Spell Attack Bonus: +5 (+2 prof + +3 INT)
10. Save Character.

**What to check specifically:**
- Spell list only shows Wizard spells, not Cleric/Druid/Barbarian spells
- High Elf gives +2 DEX and +1 INT (both visible in review)
- Spell Save DC and Spell Attack Bonus appear on Review
- Cantrips are saved and visible

---

## Test 1.3 — Create a high-level character (level 5)

**Steps:**
1. Create Character → Name: **"Kira"**, Level **5**.
2. Race: Human. Class: Rogue. Background: Criminal.
3. Assign scores however you like. Confirm.
4. Skills: Rogue gets 4 picks. Criminal gives Deception and Stealth. Pick 4 more (not Deception or Stealth).
5. Equipment and spells (Rogue has no spells).
6. **Hub should show an "Ability Improvements" section** because Rogue gets an ASI at level 4.
7. Tap Ability Improvements. The ASI/feat picker should appear.
8. Choose +2 to DEX (or take a feat). Confirm.
9. Hub: Ability Improvements ✓.
10. Review. Save.

**What to check:**
- ASI section appears at level 5 (would have been unlocked at level 4)
- After taking +2 DEX, the score on review is correctly boosted
- DEX-based skills (Stealth, Acrobatics) reflect the improved modifier

---

## Test 1.4 — Change class mid-creation (skill stacking bug)

This test specifically checks the skills stacking bug we fixed.

**Steps:**
1. Create Character → Name: **"Switcher"**, Level 1.
2. Select Race: Human.
3. Select Class: **Wizard** (picks 2 skills from the Wizard list).
4. Select Background: Sage (gives Arcana + History).
5. Go to Skills. Pick 2 from the Wizard list (e.g. Insight, Medicine). Confirm.
6. Now go back to **Class** and change to **Rogue** (picks 4 skills).
7. Go to Skills again.
8. You should see: Arcana, History pre-marked from Sage background. You should have **4** new picks from the Rogue list.
9. Pick your 4 Rogue skills. Confirm.
10. Review. Save.

**What to check:**
- After changing class, you do NOT see Insight or Medicine already marked trained from the old Wizard class
- You have exactly 4 + 2 (background) = 6 trained skills, NOT 8
- The skills from the old class are GONE

**If this fails:** the clearClassData function is not resetting skill trained flags.

---

## Test 1.5 — Re-enter a completed step

**Steps:**
1. Create a character up to the Skills step. Complete it.
2. From the Hub, tap **Skills** again.
3. You should see a **read-only summary** listing the skills you chose, not the "no choices for this class" message, and not the interactive picker again.
4. A "Continue" button should take you back to the Hub.

**What to check:**
- Re-entering a completed step shows a summary, not an error or blank screen
- You can't re-pick skills (they're already resolved)

---

## Test 1.6 — Score confirmation preserves ASI (ASI data corruption test)

This is the most critical data-integrity test.

**Steps:**
1. Create a level 5 character (any class with an ASI, e.g. Fighter).
2. Complete creation including picking the ASI (+2 STR).
3. **Note the final STR score** on review (e.g. 17 with Mountain Dwarf, 15 base + 2 ASI).
4. Go back to **Ability Scores** (from the Hub).
5. Change nothing. Just tap Confirm Scores again.
6. Go to Review.

**What to check:**
- STR is still the same value. The ASI was NOT erased by re-confirming scores.
- HP has NOT changed (no silent recalculation based on lost STR).

**If this fails:** reapplyResolvedAsi in scores.tsx is broken.

---

# PART 2 — CHARACTER SHEET

Open Thorin (the Fighter from Test 1.1) for all sheet tests.

## Test 2.1 — Combat tab baseline

**Steps:**
1. Open Thorin's sheet. Default tab should be Combat.
2. Verify the header: name, "Level 1 fighter", HP pill shows 13/13.

**Check the stat row (AC / Speed / Init / Perc):**
- Tap **AC**. An audit modal should appear showing the breakdown. Should show base 10 + DEX +1 = AC 11 (no armor equipped yet).
- Tap **Speed**. Should show 25 ft, with a Dwarf racial entry in the breakdown.
- Tap **Init**. Should show +1 (DEX modifier).
- Tap **Perc** (Passive Perception). Should show 10 + WIS mod + proficiency if trained.
- Close the modal after each.

**What to check:**
- Every stat tap opens the audit modal
- Audit modal shows real entries, not "No breakdown available"
- Values match what Review showed

---

## Test 2.2 — Damage and healing

**Steps:**
1. On Thorin's Combat tab, tap the HP block.
2. The HP modal opens. Tap **Damage**.
3. Enter 5. Confirm.
4. HP should now show **8/13**. HP bar should be shorter, and yellow.
5. Tap HP block again. Tap **Heal**.
6. Enter 3. Confirm.
7. HP should now show **11/13**.
8. Tap HP block. Damage 20 (more than current HP).
9. HP should floor at **0**, not go negative.
10. The dying state should appear: "💀 Dying — Roll Death Saves below."

**What to check:**
- Damage and heal work correctly
- HP cannot go below 0
- Dying state appears at exactly 0 HP, not at 1 HP

---

## Test 2.3 — Death saving throws

**Steps:**
1. With Thorin at 0 HP (from 2.2), find the Death Saving Throws section.
2. Tap **Roll Death Save** three times, recording each result.
3. After 3 successes: "✅ Stable — 1 HP" should appear and HP should return to 1.
4. OR after 3 failures: "💀 Dead" alert should appear.
5. Tap Reset Death Saves. Pips should clear.

**What to check:**
- Roll 1 counts as 2 failures
- Roll 20 immediately stabilizes at 1 HP
- 3 successes → stable at 1 HP
- 3 failures → dead alert
- Reset clears pips

---

## Test 2.4 — Temp HP

**Steps:**
1. Restore Thorin to full HP first (tap HP → Heal 13).
2. In the HP utility row, tap **+** next to "Temp HP: 0".
3. Enter 5. Confirm.
4. Header/HP block should show "+5 tmp" in blue.
5. Now damage for 3. Current HP unchanged. Temp HP should drop to 2.

**Note:** Temp HP in this app works as a pool that doesn't absorb damage automatically — the DM tracks it. The important thing is the display is correct.

**What to check:**
- Temp HP appears as blue "+5 tmp" display
- Tapping − clears it

---

## Test 2.5 — Conditions

**Steps:**
1. In the Conditions section, tap **+ Add**.
2. A bottom sheet appears with a list of conditions. Search for "poi".
3. "Poisoned" should appear. Tap it.
4. Modal closes. Poisoned chip appears in the Conditions section.
5. Below it, a warning should appear: **"⚠ poisoned: Disadvantage on attacks and ability checks"**
6. Add a second condition: **Restrained**.
7. Warning should appear for Restrained too.
8. Tap the ✕ on Poisoned. Poisoned chip and its warning should disappear.

**What to check:**
- All 15 standard conditions are available in the list
- Mechanical warning appears under the chip for known conditions
- Removing the chip removes the warning
- Multiple conditions can be active simultaneously

---

## Test 2.6 — Hit Dice

**Steps:**
1. Find the Hit Dice section. Thorin has 1/1 hit dice (d10).
2. First damage Thorin to 5 HP.
3. Tap **🎲 Roll Hit Die**. An alert should appear saying "Restored X HP. Hit dice remaining: 0/1."
4. Verify Thorin's HP increased by that amount.
5. The Roll Hit Die and Use Hit Die buttons should now be greyed out (0 remaining).

**Also test Use Hit Die:**
1. After a long rest (so hit dice refill), tap **Use Hit Die**.
2. Alert: "Spent one hit die — roll your own dice and heal manually. Remaining: 0/1."
3. HP is NOT automatically increased.

**What to check:**
- Roll Hit Die heals automatically
- Use Hit Die only spends (no healing)
- Both buttons disable at 0 remaining
- CON modifier is applied correctly in Roll Hit Die

---

## Test 2.7 — Level Up in-play

**Steps:**
1. On the Combat tab, find **⬆ Level Up (→ 2)**.
2. Tap it. A confirmation alert: "Level up Thorin from 1 to 2?"
3. Confirm. HP should increase (Fighter gets 10 max — fighter's d10 average, or max + CON).
4. Level in the header updates to 2.

**Now test ASI level-up (need level 4):**
1. Level up to 3, then 4.
2. At level 4, after confirming level-up, the **ASI/Feat picker** should automatically open.
3. Choose +2 STR. Confirm.
4. Go to the Abilities tab. STR should be 2 higher.
5. Any STR-based skills (Athletics) should reflect the new modifier.

**What to check:**
- HP increases each level
- Level counter in header updates
- ASI picker opens automatically at level 4, 8, 12, 16, 19
- Ability scores on Abilities tab update after ASI

---

## Test 2.8 — Equip armor and check AC

**Steps:**
1. Go to the **Inventory tab**.
2. Find a piece of armor in Carried (e.g. scale mail from Cleric starting gear, or use Thorin's starting Fighter gear).
3. Tap **Equip** next to the armor.
4. Return to the **Combat tab**.
5. Tap AC in the stat row. The audit modal should show the armor's contribution.

**What to check:**
- AC changes when armor is equipped
- Audit modal shows the armor name and its value
- Light armor adds DEX modifier (e.g. Leather: 11 + DEX)
- Heavy armor is flat (e.g. Chain Mail: 16)

---

# PART 3 — ABILITIES TAB

## Test 3.1 — Ability scores show racial bonuses

**Steps:**
1. Open Thorin's Abilities tab.
2. The six ability scores should show EFFECTIVE values (base + race).
3. STR should show 17 (not 15). CON should show 16 (not 14).
4. Tap STR. The audit modal should show:
   - Base: 15
   - Mountain Dwarf: +2
   - Total: 17

**What to check:**
- Abilities tab shows effective scores, NOT base scores
- Racial bonuses appear in the audit trail
- Modifier is correct for the effective score (+3 for STR 17, not +2 for STR 15)

---

## Test 3.2 — Saving throws

**Steps:**
1. On the Abilities tab, find Saving Throws.
2. Fighter is proficient in STR and CON saves.
3. STR save: STR modifier (+3) + proficiency (+2) = **+5**. A filled dot should appear.
4. DEX save: DEX modifier (+1) + 0 proficiency = **+1**. No filled dot.
5. Tap STR save. Audit modal should show the breakdown.

---

## Test 3.3 — Skills

**Steps:**
1. Athletics and Intimidation (from Soldier background) should show as trained (filled dot) with +2 proficiency included.
2. Athletics bonus: STR mod (+3) + proficiency (+2) = **+5**.
3. A skill Thorin didn't pick (e.g. Acrobatics): DEX mod (+1) + 0 = **+1**.
4. Tap Athletics. Audit modal should show: STR mod +3, Proficiency +2, Total +5.

---

# PART 4 — FEATURES TAB

## Test 4.1 — Features listed correctly

**Steps:**
1. Open the Features tab.
2. Fighter level 1 should show:
   - Race section: Dwarven Resilience, Stonecunning, Darkvision (if applicable), and Mountain Dwarf features
   - Class section: Fighting Style, Second Wind
   - Background section: Military Rank

**What to check:**
- Features grouped by source (Race / Class / Background)
- No duplicate features
- Feature names are readable game terms, not engine terminology

---

## Test 4.2 — Pending choices

**Steps:**
1. If any choices are unresolved (e.g. a skill not yet picked), they appear at the top of the Features tab.
2. For a Wizard, unresolved spells or skills should show here.
3. Skill choices: tap chips to select, tap Confirm.
4. ASI choices: a button opens the ASI picker.

---

# PART 5 — ACTIONS TAB

## Test 5.1 — Actions generate correctly

**Steps:**
1. Open Thorin's Actions tab.
2. Fighter level 1 should have **Second Wind** as a Bonus Action.
3. The card should show:
   - Layer 1: "Class • Bonus Action • Healing"
   - Layer 2: "Heal 1d10+[level]" or similar
   - Use button: active (gold)
4. Tap **Use**. A modal opens with the ability description.
5. If there's a dice expression, tap Roll. A number appears.

**What to check:**
- Second Wind appears as a card (not just in Features)
- Card color is green (healing)
- Use button is tappable
- Rolling shows a result

---

## Test 5.2 — Unavailable actions show correct reason

**Steps:**
1. Use Second Wind once (it costs 1 resource from the Second Wind pool).
2. Go back to Actions tab.
3. Second Wind should now be greyed out with a reason: "second wind: 0/1 remaining" or similar.
4. The Use button should say "N/A" and be non-tappable.

---

## Test 5.3 — Spellcaster actions (use Elara)

**Steps:**
1. Open Elara (the Wizard from Test 1.2).
2. Actions tab should have:
   - Actions section: damage spells (Fire Bolt as action), utility spells
   - The cantrip Fire Bolt should show "Lv 0 Spell • Evocation • Damage"
3. A leveled spell (Magic Missile) should show "Slot Lv 1+" in layer 3.
4. Use Magic Missile. It should consume a level-1 spell slot.
5. Check the Combat tab. The level-1 slot pip should now be used (dimmed).

---

# PART 6 — INVENTORY TAB

## Test 6.1 — Equip and carry

**Steps:**
1. Open Inventory. Find items in Carried.
2. Tap Equip on a weapon. It moves to Equipped.
3. Go to Combat tab. The Attacks section should show that weapon.
4. The attack bonus should be proficiency + STR mod (for a melee weapon).
5. Go back to Inventory. Tap Unequip. Weapon returns to Carried.
6. Go to Combat. Weapon no longer appears in Attacks.

**What to check:**
- Equip/unequip moves item between lists correctly
- Combat tab Attacks section updates immediately
- AC updates when armor is equipped

---

# PART 7 — REST

## Test 7.1 — Short rest

**Steps:**
1. Spend Thorin's hit dice and use Second Wind.
2. Scroll to the bottom of any sheet tab. Find the rest bar.
3. Tap **☕ Short Rest**.
4. Short-rest resources (Second Wind) refill.
5. Hit dice spending prompt appears (optional healing).

**What to check:**
- Short-rest resources (Channel Divinity, Ki, Bardic Inspiration, Second Wind) refill
- Spell slots do NOT refill on short rest (except Warlock)
- HP is NOT automatically restored (you spend hit dice optionally)

---

## Test 7.2 — Long rest

**Steps:**
1. Take some damage and spend spell slots.
2. Tap **🌙 Long Rest**.
3. After confirming:
   - HP restores to maximum
   - All spell slots refill
   - Hit dice pool restores (up to half total, per PHB)
   - Second Wind refills

**What to check:**
- HP at maximum after long rest
- All spell slot pips unfilled (available) after long rest
- Resources with "long rest" recharge are full

---

# PART 8 — CAMPAIGNS

## Test 8.1 — Create a campaign (DM)

**Steps:**
1. Go to the Campaigns tab.
2. Enter a nickname in the "YOUR NAME" field.
3. Tap **Create Campaign (DM)**.
4. Enter a campaign name: "Test Campaign". Tap Create Campaign.
5. A campaign view should appear showing:
   - Campaign name
   - A 6-digit room code (large bold text)
   - A QR code
   - "Open DM Dashboard" button
6. Tap **Open DM Dashboard**.
7. Dashboard shows "PARTY (0)" and a "Start Encounter" button.

**What to check:**
- Room code appears (6 characters)
- QR code renders
- DM Dashboard is accessible

---

## Test 8.2 — End campaign

**Steps:**
1. From the campaign view, scroll down to **End Campaign** (red button).
2. Tap it. Confirm.
3. Campaign view clears. "No Active Campaign" state returns.

---

# PART 9 — HOMEBREW

## Test 9.1 — Create a homebrew spell

**Steps:**
1. Go to Homebrew tab.
2. In the Create section, tap **✨ New Spell**.
3. Fill in:
   - Name: "Arcane Bolt"
   - Level: 1
   - School: Evocation
   - Casting Time: 1 action
   - Range: 60 feet
   - Components: V, S
   - Duration: Instantaneous
   - Description: "You hurl a bolt of arcane energy. The target takes 2d8 force damage."
4. Tap **Save Spell**.
5. An alert: "Saved! 'Arcane Bolt' added to your homebrew library."
6. Go back. In the Library panel, "Arcane Bolt" should appear with a blue "spell" badge.

**What to check:**
- Form validation works (try saving with no name — should be blocked)
- Saved item appears in Library
- Type badge is colored correctly

---

## Test 9.2 — Create a homebrew race

**Steps:**
1. Tap **⚔️ New Race** (this opens the race builder).
2. Fill in:
   - Name: "Aasimar"
   - Speed: 30
   - Ability bonuses: CHA +2
   - Darkvision: toggle on
   - Extra trait: "Celestial Resistance"
3. Save.
4. "Aasimar" should appear in Library with a green "race" badge.

---

## Test 9.3 — Delete homebrew item

**Steps:**
1. In the Library, tap 🗑 on the "Arcane Bolt" spell.
2. Confirm deletion.
3. Item disappears from Library.

---

# PART 10 — GENERAL NAVIGATION

## Test 10.1 — Back navigation

**Steps:**
1. From the Characters tab, open a character sheet.
2. On the sheet, tap the back arrow.
3. You should return to the Characters tab, not crash.
4. Open the sheet again. Switch through all 6 tabs. No crashes.

---

## Test 10.2 — App restart persistence

**Steps:**
1. Create a character (Thorin from Test 1.1 if not already done).
2. Damage Thorin to 7 HP. Note the value.
3. Force-close the app completely (swipe away from app switcher).
4. Reopen the app.
5. Open Thorin's sheet.

**What to check:**
- Character exists after restart
- HP is 7 (the damaged value persists — not reset to full)
- All skills, features, and equipment are intact

---

## Test 10.3 — Home screen

**Steps:**
1. On the Home tab, verify the "Continue Last Character" card shows:
   - Thorin's name
   - Level, class, race
   - HP bar with correct percentage
   - AC and Speed badges
2. Tap the card. Should open Thorin's sheet.

---

# PART 11 — EDGE CASES

## Test 11.1 — Characters with no background skills overlap

Create a Rogue with the Criminal background.
Criminal gives Deception and Stealth.
Rogue's skill list includes both Deception and Stealth.
On the Skills screen, Deception and Stealth should be pre-marked and disabled.
You should still have 4 more picks from the remaining 9 skills.

---

## Test 11.2 — All Standard Array values can be assigned

On the scores screen, standard array:
1. Assign all 6 values to all 6 abilities.
2. Every value is used exactly once.
3. Confirm. No crash.

---

## Test 11.3 — Characters tab handles multiple characters

1. Create 3–4 different characters.
2. Characters tab shows all of them as cards.
3. Each card shows the correct name, class, and HP.
4. Long-pressing one shows a delete confirm for that character specifically.
5. Deleting one doesn't affect the others.

---

# QUICK REGRESSION CHECKLIST

Run this after any code change. Takes ~5 minutes.

- [ ] Create a level 1 Human Fighter. HP = 10 + CON mod. AC = 10 + DEX mod (no armor).
- [ ] Racial bonus appears on Abilities tab (not just at creation review).
- [ ] Tapping any stat opens an audit modal with real entries.
- [ ] Damaging HP updates the bar color.
- [ ] Conditions show mechanical reminders when added.
- [ ] Equipping armor changes AC.
- [ ] Long rest restores HP to max and refills spell slots.
- [ ] Changing class resets skills (no stacking from old class).
- [ ] Re-entering the Skills screen after completion shows a summary, not an error.
- [ ] App restart preserves HP and character data.

---

# KNOWN LIMITATIONS (don't file as bugs)

- Spells tab doesn't exist yet — spells are accessed via the Actions tab.
- Settings screen doesn't exist yet — CampaignRules cannot be changed in-app.
- Homebrew items don't appear in the creation wizard yet (saved but not wired in).
- Two-device sync has not been tested — treat multiplayer as experimental.
- Subclass features beyond level 1 are mostly not authored.
- Medium armor DEX bonus is not capped at +2 (pipeline limitation).
